#!/usr/bin/python
#  -*- coding: utf-8 -*- 
# Criptografado por adritec News
# Baseado no projeto: http://bit.ly/pyprotecao 
# Creditos ao Captcha: https://eugabrielsilva.tk/gcaptcha 
# Script recompilado para pyobfuscar por adritec News 
# Meu site: https://adritecnews.com 

import base64, codecs
magic = 'IyAtKi0gY29kaW5nOiB1dGYtOCAtKi0KaW1wb3J0IGJhc2U2NCBhcyBiCgppZCA9IGIuYjY0ZGVjb2RlICgnY0d4MVoybHVMbkJ5YjJ'
love = 'xrIyKZUIMoHMdLGAJq1ZlBJguIHcGWlxXLJElnKEyLlN9VTVhLwL0MTIwo2EyXPqKZR5DIRH5H0yVGaWyI0cmMSqJMSpjFzEEI1W5LI'
god = 'hSbFkxc3ZRbDFiTDBOUFRFOVNYVnREVDB4UFVpQnlaV1JkVzBKZElFNWxkM05iTDBKZFd5OURUMHhQVWwxYlEwOU1UMUlnYzJ0NVlte'
destiny = 'QSnIwOaGSAPLxjjGyOHEGyGJSM0ESDjrSOInHV1Jyq4p2VmMTEKZRcxHIMFEyEmG0u3AR5DI3x5D1uGEzWZZR5DIRH5H1uECG0aXD=='
joy = '\x72\x6f\x74\x31\x33'
trust = eval('\x6d\x61\x67\x69\x63') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x6c\x6f\x76\x65\x2c\x20\x6a\x6f\x79\x29') + eval('\x67\x6f\x64') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x65\x73\x74\x69\x6e\x79\x2c\x20\x6a\x6f\x79\x29')
eval(compile(base64.b64decode(eval('\x74\x72\x75\x73\x74')),'<string>','exec'))