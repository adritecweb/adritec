#!/usr/bin/python
#  -*- coding: utf-8 -*- 
# Criptografado por adritec News
# Baseado no projeto: http://bit.ly/pyprotecao 
# Creditos ao Captcha: https://eugabrielsilva.tk/gcaptcha 
# Script recompilado para pyobfuscar por adritec News 
# Meu site: https://adritecnews.com 

import base64, codecs
magic = 'aW1wb3J0IG9zLCB4Ym1jLCB4Ym1jZ3VpLCB4Ym1jYWRkb24NCmZyb20gZGF0ZXRpbWUgaW1wb3J0IGRhdGUNCg0KYWRkb24gPSB4Ym1jYWRkb24uQWRkb24oaWQgPSAncGx1Z2luLnZpZGVvLnByb2pldG9hZHJpdGVjbmV3cycpDQpBZGRvblRpdGxlID0gIltDT0xPUiB3aGl0ZV0nW0JdT0JSSUdBRE9bL0JdWy9DT0xPUl0gW0NPTE9SIHNreWJsdWVdW0JdUE9SIFsvQl1bL0NPTE9SXSBbQ09MT1IgbGltZV1bQl1DT0xBQk9SQVJbL0JdWy9DT0xPUl1bQ09MT1IgeWV'
love = 'foT93KIgPKFSoY0WqW1fiD09ZG1WqVt0XpUWiMzyfMFN9VTSxMT9hYzqyqRSxMT9hFJ5zoltapUWiMzyfMFpcQDcbo21yVQ0tLJExo24hM2I0DJExo25WozMiXPqjLKEbWlxAPzEcLJkiMlN9VUuvoJAaqJxhETyuoT9aXPxtVNxWQDbAPzEyMvOuMUVlXPx6QDbWGJIhVQ0trTWgLl50pzShp2kuqTIDLKEbXT9mYaOuqTthnz9covubo21yYPNaLJElYzSxpzy0MJZaXFxAPtyZLKA0K2EurFN9VUA0pvuxLKEyYaEiMTS5XPxcQDbWLJ5uoUy6MFN9VT9jMJ4bGJIhYPqlLv'
god = 'cpLnJlYWQoKQ0KCWlmIG5vdCBhbmFseXplID09IExhc3RfZGF5Og0KCQliID0gb3BlbihNZW4sIndiIikNCgkJYi53cml0ZShMYXN0X2RheSkNCgkJYi5jbG9zZSgpDQoJCWRpYWxvZy5vayhBZGRvblRpdGxlLCdbQ09MT1IgbGltZV1bQl0qWy9CXVsvQ09MT1JdW0NPTE9SIHdoaXRlXVtCXU5vbWVzWy9CXSBkb3MgWy9DT0xPUl1bQ09MT1Igd2hpdGVdW0JdQ29sYWJvcmFkb3Jlc1svQl0gZG8gW0JdbcOqc1svQl0hWy9DT0xPUl1bQ1JdW0JdQ29uZmlyYSBlbVsvQ'
destiny = 'y06VSgQG0kCHvOfnJ1yKIgPKpX7Jl9PKIfiD09ZG1WqJ0ACGR9FVTqioTEqJ0WqD29fLJWipzSxo3Wyp1fiDy0tMT8tJ0WqGpBdp1fiDy0uJl9QG0kCHy0aYPqoD09ZG1Vtq2ucqTIqJ0WqGJScplO1oJRtMz9loJRtMTHtEIHtpzIwo21jMJ5mLKVtIx9Qj4btJl9PKFSoY0ACGR9FKFpfW1gQG0kCHvO3nTy0MI1oDy1HnTShnlO5o3HtqzIlrFOgqJAbJl9PKFSoY0ACGR9FKFNgVSgQG0kCHvO3nTy0MI1oDy1AMKHtoKIcqT8to2WlnJquMT9oY0WqVIfiD09ZG1WqWlx='
joy = '\x72\x6f\x74\x31\x33'
trust = eval('\x6d\x61\x67\x69\x63') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x6c\x6f\x76\x65\x2c\x20\x6a\x6f\x79\x29') + eval('\x67\x6f\x64') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x65\x73\x74\x69\x6e\x79\x2c\x20\x6a\x6f\x79\x29')
eval(compile(base64.b64decode(eval('\x74\x72\x75\x73\x74')),'<string>','exec'))